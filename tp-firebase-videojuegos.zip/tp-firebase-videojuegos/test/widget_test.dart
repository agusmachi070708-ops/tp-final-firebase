import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ludoteca/pantallas/pantalla_login.dart';
import 'package:ludoteca/pantallas/pantalla_registro.dart';

// Estas pruebas no necesitan Firebase: verifican que los formularios se
// validen antes de enviarle algo.

void main() {
  testWidgets('El login no deja ingresar con los campos vacíos',
      (tester) async {
    await tester.pumpWidget(
      const ProviderScope(child: MaterialApp(home: PantallaLogin())),
    );

    await tester.ensureVisible(find.text('Ingresar'));
    await tester.tap(find.text('Ingresar'));
    await tester.pump();

    expect(find.text('Completá el email.'), findsOneWidget);
    expect(find.text('Completá la contraseña.'), findsOneWidget);
  });

  testWidgets('El registro avisa si las contraseñas no coinciden',
      (tester) async {
    await tester.pumpWidget(
      const ProviderScope(child: MaterialApp(home: PantallaRegistro())),
    );

    await tester.enterText(
      find.widgetWithText(TextFormField, 'Nombre'),
      'Máximo',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Email'),
      'maximo@mail.com',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Contraseña'),
      'secreta1',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Repetir contraseña'),
      'secreta2',
    );

    await tester.ensureVisible(find.text('Crear cuenta'));
    await tester.tap(find.text('Crear cuenta'));
    await tester.pump();

    expect(find.text('Las contraseñas no coinciden.'), findsOneWidget);
  });
}
