import 'package:flutter_test/flutter_test.dart';
import 'package:ludoteca/utils/validadores.dart';

void main() {
  group('validarEmail', () {
    test('acepta un email válido', () {
      expect(validarEmail('maximo@mail.com'), isNull);
    });

    test('rechaza un email sin arroba', () {
      expect(validarEmail('maximo.mail.com'), 'Ingresá un email válido.');
    });

    test('rechaza un email vacío', () {
      expect(validarEmail('   '), 'Completá el email.');
    });
  });

  group('validarContrasena', () {
    test('exige al menos 6 caracteres', () {
      expect(validarContrasena('12345'), isNotNull);
      expect(validarContrasena('123456'), isNull);
    });
  });

  group('validarConfirmacion', () {
    test('pasa si las contraseñas coinciden', () {
      expect(validarConfirmacion('secreta1', 'secreta1'), isNull);
    });

    test('falla si las contraseñas no coinciden', () {
      expect(
        validarConfirmacion('secreta1', 'secreta2'),
        'Las contraseñas no coinciden.',
      );
    });
  });

  group('validarUrlImagen', () {
    test('acepta una URL http o https', () {
      expect(validarUrlImagen('https://ejemplo.com/portada.jpg'), isNull);
    });

    test('rechaza texto que no es una URL', () {
      expect(validarUrlImagen('portada.jpg'), isNotNull);
      expect(validarUrlImagen('ftp://ejemplo.com/portada.jpg'), isNotNull);
    });
  });

  group('validarAnio', () {
    test('acepta un año razonable', () {
      expect(validarAnio('1998'), isNull);
    });

    test('rechaza años fuera de rango o texto', () {
      expect(validarAnio('1800'), isNotNull);
      expect(validarAnio('${DateTime.now().year + 10}'), isNotNull);
      expect(validarAnio('abc'), isNotNull);
    });
  });
}
