# Ludoteca — TP Firebase

Aplicación móvil en Flutter para administrar una colección de videojuegos. Permite registrarse, iniciar sesión y dar de alta, ver, editar y eliminar videojuegos guardados en Cloud Firestore.

**Autor:** Máximo Pérez Rodríguez

## Tecnologías

- **Flutter** para la interfaz.
- **Firebase Authentication** (email y contraseña) para el registro y el inicio de sesión.
- **Cloud Firestore** para guardar los videojuegos.
- **Riverpod 3** para manejar el estado.
- **go_router** para la navegación y la redirección según la sesión.

## Funcionalidades

| Requisito de la consigna | Dónde está resuelto |
|---|---|
| Registro con nombre, email, contraseña y confirmación, con validaciones | `pantallas/pantalla_registro.dart`, `utils/validadores.dart` |
| El nombre queda asociado al perfil del usuario | `repositorios/auth_repositorio.dart` (`updateDisplayName`) |
| Mensaje claro si Firebase rechaza el registro o el login | `utils/errores.dart` |
| Inicio y cierre de sesión | `pantallas/pantalla_login.dart`, `pantallas/pantalla_listado.dart` |
| Comprobar si hay una sesión activa al abrir la app | `router/app_router.dart` (`redirect`) + `usuarioActualProvider` |
| Listado desde Firestore (título, imagen y plataforma/año) | `pantallas/pantalla_listado.dart` + `videojuegosProvider` |
| Detalle con opciones de edición y eliminación | `pantallas/pantalla_detalle.dart` |
| Alta con validación de campos obligatorios | `pantallas/pantalla_formulario.dart` + `AbmVideojuegosController.crear` |
| Modificación del mismo documento | `pantallas/pantalla_formulario.dart` + `AbmVideojuegosController.actualizar` |
| Baja (borra el documento de Firestore) | `pantallas/pantalla_detalle.dart` + `AbmVideojuegosController.eliminar` |
| Gestión de estado con Riverpod | carpeta `providers/` |

## Estructura del proyecto

```
lib/
├── main.dart              Inicializa Firebase y arranca la app dentro de ProviderScope
├── app.dart               MaterialApp con el tema y el router
├── modelos/
│   └── videojuego.dart    Modelo y conversión desde/hacia Firestore
├── repositorios/          Único lugar donde se habla con Firebase
│   ├── auth_repositorio.dart
│   └── videojuegos_repositorio.dart
├── providers/             Estado de la app con Riverpod
│   ├── auth_providers.dart
│   └── videojuegos_providers.dart
├── router/
│   ├── app_router.dart    Rutas y redirección según la sesión
│   └── rutas.dart         Direcciones de las pantallas
├── pantallas/             Carga, login, registro, listado, detalle y formulario
├── widgets/               Componentes reutilizables (campo de texto, botón, imagen...)
└── utils/                 Validaciones de formularios y mensajes de error
```

## Cómo funciona

### Sesión

`usuarioActualProvider` es un `StreamProvider` que escucha `FirebaseAuth.userChanges()`: emite el usuario logueado o `null` si no hay sesión. Al abrir la app arranca en estado "cargando" hasta que Firebase responde si quedó una sesión guardada en el dispositivo.

El router copia ese estado en un `ValueNotifier` y lo usa como `refreshListenable`. Cada vez que la sesión cambia, se ejecuta `redirect`:

1. Mientras Firebase no respondió, se muestra la pantalla de carga.
2. Sin sesión, solo se puede estar en el login o en el registro.
3. Con sesión, el login, el registro y la pantalla de carga llevan al listado.

Por eso las pantallas nunca navegan "a mano" después de iniciar o cerrar sesión: el router reacciona solo. Las contraseñas no se guardan en la app; se le pasan directamente a Firebase Authentication.

### Listado y detalle en tiempo real

`videojuegosProvider` y `videojuegoProvider(id)` son `StreamProvider` construidos sobre `snapshots()` de Firestore. Cada vez que un documento se crea, se edita o se borra, Firestore avisa y Riverpod vuelve a dibujar las pantallas que los usan. Así el listado y el detalle reflejan los cambios sin recargar nada.

Los dos son `autoDispose`: cuando ninguna pantalla los usa (por ejemplo, después de cerrar sesión), se corta la conexión con Firestore.

### Alta, modificación y baja

`AbmVideojuegosController` es un `AsyncNotifier` con tres métodos: `crear` (usa `add`, y Firestore genera el ID), `actualizar` (usa `update` sobre el mismo ID) y `eliminar` (usa `delete`). Mientras una operación está en curso, su estado es `AsyncLoading`, y el formulario lo usa para deshabilitar el botón y mostrar el indicador de carga. Si algo falla, devuelve un mensaje que se muestra en pantalla.

El mismo formulario sirve para el alta y para la edición: si recibe un ID, primero trae el videojuego de Firestore y completa los campos con los datos actuales.

### Providers

| Provider | Tipo | Para qué |
|---|---|---|
| `usuarioActualProvider` | `StreamProvider<User?>` | Estado de la sesión (lo escucha el router) |
| `usuarioLogueadoProvider` | `Provider<User?>` | Atajo para mostrar el nombre en el listado |
| `sesionControllerProvider` | `AsyncNotifierProvider` | Iniciar sesión, registrarse y cerrar sesión |
| `videojuegosProvider` | `StreamProvider.autoDispose` | Listado en tiempo real |
| `videojuegoProvider(id)` | `StreamProvider.autoDispose.family` | Un videojuego en tiempo real |
| `abmVideojuegosProvider` | `AsyncNotifierProvider` | Alta, modificación y baja |
| `routerProvider` | `Provider<GoRouter>` | Configuración de la navegación |

## Modelo de datos

Colección `videojuegos` en Cloud Firestore. El ID de cada documento es el identificador único del videojuego.

| Campo | Tipo | Ejemplo |
|---|---|---|
| `titulo` | string | Hollow Knight |
| `descripcion` | string | Metroidvania en un reino de insectos... |
| `imagenUrl` | string | https://... |
| `plataforma` | string | PC |
| `genero` | string | Metroidvania |
| `desarrolladora` | string | Team Cherry |
| `anioLanzamiento` | number | 2017 |

## Cómo ejecutarlo

### 1. Preparar Firebase

1. Crear un proyecto en la [consola de Firebase](https://console.firebase.google.com/).
2. En **Authentication → Método de acceso**, habilitar **Correo electrónico/contraseña**.
3. En **Firestore Database**, crear la base de datos.
4. En **Firestore Database → Reglas**, pegar el contenido de [`firestore.rules`](firestore.rules) y publicar.

### 2. Preparar el proyecto

Hace falta tener instalados Flutter y la [Firebase CLI](https://firebase.google.com/docs/cli) (`npm install -g firebase-tools`).

```bash
# Genera las carpetas de Android e iOS (no pisa el código que ya existe)
flutter create . --project-name ludoteca --org com.maximoperez --platforms=android,ios

# Descarga las dependencias
flutter pub get

# Conecta la app con el proyecto de Firebase y genera lib/firebase_options.dart
dart pub global activate flutterfire_cli
firebase login
flutterfire configure

# Ejecuta la app en el emulador o el celular conectado
flutter run
```

### 3. Comprobar la persistencia

1. Registrarse, agregar un videojuego y cerrar la app por completo. Al volver a abrirla, la sesión sigue iniciada y el videojuego aparece en el listado.
2. Editarlo, cerrar y volver a abrir: se ven los cambios.
3. Eliminarlo, cerrar y volver a abrir: ya no aparece.

## Tests

```bash
flutter test
```

Prueban las validaciones y que los formularios de login y registro no envíen nada a Firebase si hay datos incompletos o las contraseñas no coinciden. No necesitan conexión con Firebase.

## Problemas comunes

- **Error de `minSdkVersion` al compilar para Android:** en `android/app/build.gradle.kts`, cambiar `minSdk = flutter.minSdkVersion` por `minSdk = 23`.
- **"No tenés permiso para hacer esto":** las reglas de Firestore no están publicadas o no hay sesión iniciada.
- **La imagen no carga:** la URL tiene que ser el enlace directo a la imagen (por ejemplo, con clic derecho → "Copiar dirección de imagen") y conviene que empiece con `https://`, porque Android bloquea por defecto las imágenes por `http://`.
- **APK de release sin conexión:** agregar `<uses-permission android:name="android.permission.INTERNET"/>` en `android/app/src/main/AndroidManifest.xml`. En modo debug ya viene incluido.
