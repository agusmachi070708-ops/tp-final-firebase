// Validaciones de los formularios.
// Cada función devuelve null si el valor es válido, o el mensaje de error
// que se muestra debajo del campo.

String? validarObligatorio(String? valor, String campo) {
  if (valor == null || valor.trim().isEmpty) return 'Completá $campo.';
  return null;
}

final _formatoEmail = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');

String? validarEmail(String? valor) {
  final email = valor?.trim() ?? '';
  if (email.isEmpty) return 'Completá el email.';
  if (!_formatoEmail.hasMatch(email)) return 'Ingresá un email válido.';
  return null;
}

/// Firebase Authentication exige contraseñas de al menos 6 caracteres.
String? validarContrasena(String? valor) {
  if (valor == null || valor.isEmpty) return 'Completá la contraseña.';
  if (valor.length < 6) return 'Tiene que tener al menos 6 caracteres.';
  return null;
}

String? validarConfirmacion(String? valor, String contrasena) {
  if (valor == null || valor.isEmpty) return 'Repetí la contraseña.';
  if (valor != contrasena) return 'Las contraseñas no coinciden.';
  return null;
}

String? validarUrlImagen(String? valor) {
  final texto = valor?.trim() ?? '';
  if (texto.isEmpty) return 'Completá la URL de la imagen.';
  final url = Uri.tryParse(texto);
  final esValida = url != null &&
      (url.scheme == 'http' || url.scheme == 'https') &&
      url.host.isNotEmpty;
  if (!esValida) return 'La URL tiene que empezar con http:// o https://';
  return null;
}

String? validarAnio(String? valor) {
  final texto = valor?.trim() ?? '';
  if (texto.isEmpty) return 'Completá el año.';
  final anio = int.tryParse(texto);
  final maximo = DateTime.now().year + 2;
  if (anio == null || anio < 1950 || anio > maximo) {
    return 'Ingresá un año entre 1950 y $maximo.';
  }
  return null;
}
