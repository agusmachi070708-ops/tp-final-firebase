import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

/// Convierte un error de Firebase en un mensaje claro, en español, para
/// mostrarle al usuario.
String describirError(Object? error) {
  // Errores de Firebase Authentication (registro e inicio de sesión).
  if (error is FirebaseAuthException) {
    return switch (error.code) {
      'invalid-email' => 'El email no tiene un formato válido.',
      'user-disabled' => 'Esta cuenta está deshabilitada.',
      'user-not-found' ||
      'wrong-password' ||
      'invalid-credential' =>
        'Email o contraseña incorrectos.',
      'email-already-in-use' => 'Ya existe una cuenta con ese email.',
      'weak-password' =>
        'La contraseña es muy débil. Usá al menos 6 caracteres.',
      'too-many-requests' =>
        'Demasiados intentos seguidos. Esperá un momento y probá de nuevo.',
      'network-request-failed' => 'No hay conexión a internet.',
      'operation-not-allowed' =>
        'El ingreso con email y contraseña no está habilitado en Firebase.',
      _ => 'No se pudo completar la operación (${error.code}).',
    };
  }

  // Errores de Cloud Firestore (listado y ABM).
  if (error is FirebaseException) {
    return switch (error.code) {
      'permission-denied' =>
        'No tenés permiso para hacer esto. Revisá las reglas de Firestore.',
      'not-found' => 'El videojuego ya no existe.',
      'unavailable' => 'No se pudo conectar con el servidor. Probá de nuevo.',
      _ => 'Error de Firebase (${error.code}).',
    };
  }

  return 'Ocurrió un error inesperado. Probá de nuevo.';
}
