import 'package:cloud_firestore/cloud_firestore.dart';

/// Un videojuego de la colección. Cada videojuego es un documento de la
/// colección "videojuegos" en Cloud Firestore.
class Videojuego {
  const Videojuego({
    this.id = '',
    required this.titulo,
    required this.descripcion,
    required this.imagenUrl,
    required this.plataforma,
    required this.genero,
    required this.desarrolladora,
    required this.anioLanzamiento,
  });

  /// Identificador único: es el ID del documento en Firestore.
  /// Queda vacío mientras el videojuego todavía no se guardó.
  final String id;
  final String titulo;
  final String descripcion;

  /// URL pública de la imagen (portada o captura del juego).
  final String imagenUrl;

  // Datos propios de la temática.
  final String plataforma;
  final String genero;
  final String desarrolladora;
  final int anioLanzamiento;

  /// Arma un Videojuego a partir de un documento leído de Firestore.
  /// Si falta algún campo, usa un valor por defecto para no romper la app.
  factory Videojuego.desdeFirestore(
    DocumentSnapshot<Map<String, dynamic>> documento,
  ) {
    final datos = documento.data() ?? <String, dynamic>{};
    return Videojuego(
      id: documento.id,
      titulo: datos['titulo'] as String? ?? '',
      descripcion: datos['descripcion'] as String? ?? '',
      imagenUrl: datos['imagenUrl'] as String? ?? '',
      plataforma: datos['plataforma'] as String? ?? '',
      genero: datos['genero'] as String? ?? '',
      desarrolladora: datos['desarrolladora'] as String? ?? '',
      anioLanzamiento: (datos['anioLanzamiento'] as num?)?.toInt() ?? 0,
    );
  }

  /// Convierte el videojuego en el mapa que se guarda en Firestore.
  /// El id no se incluye porque ya es el ID del propio documento.
  Map<String, dynamic> aFirestore() {
    return {
      'titulo': titulo,
      'descripcion': descripcion,
      'imagenUrl': imagenUrl,
      'plataforma': plataforma,
      'genero': genero,
      'desarrolladora': desarrolladora,
      'anioLanzamiento': anioLanzamiento,
    };
  }
}
