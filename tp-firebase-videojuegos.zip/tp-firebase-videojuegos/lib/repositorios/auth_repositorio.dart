import 'package:firebase_auth/firebase_auth.dart';

/// Todo lo relacionado con Firebase Authentication pasa por esta clase.
///
/// La app nunca guarda contraseñas: se le pasan directamente a Firebase,
/// que es quien las administra.
class AuthRepositorio {
  AuthRepositorio(this._auth);

  final FirebaseAuth _auth;

  /// Emite el usuario actual cada vez que alguien inicia o cierra sesión, y
  /// también cuando cambia su perfil (por ejemplo, al guardarle el nombre).
  /// Emite null cuando no hay ninguna sesión activa.
  Stream<User?> cambiosDeUsuario() => _auth.userChanges();

  Future<void> iniciarSesion({
    required String email,
    required String contrasena,
  }) async {
    await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: contrasena,
    );
  }

  /// Crea la cuenta en Firebase y le asocia el nombre al perfil del usuario.
  Future<void> registrar({
    required String nombre,
    required String email,
    required String contrasena,
  }) async {
    final credencial = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: contrasena,
    );
    await credencial.user?.updateDisplayName(nombre.trim());
    // Recargamos el usuario para que el nombre quede disponible enseguida.
    await credencial.user?.reload();
  }

  Future<void> cerrarSesion() => _auth.signOut();
}
