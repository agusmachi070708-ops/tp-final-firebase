import 'package:cloud_firestore/cloud_firestore.dart';

import '../modelos/videojuego.dart';

/// Lecturas y escrituras sobre la colección "videojuegos" de Cloud Firestore.
class VideojuegosRepositorio {
  VideojuegosRepositorio(this._db);

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> get _coleccion =>
      _db.collection('videojuegos');

  /// Todos los videojuegos ordenados por título.
  ///
  /// Es un stream: Firestore avisa cada vez que algo cambia en la colección,
  /// así que las altas, ediciones y bajas aparecen solas en el listado.
  Stream<List<Videojuego>> escucharTodos() {
    return _coleccion.orderBy('titulo').snapshots().map(
          (consulta) =>
              consulta.docs.map(Videojuego.desdeFirestore).toList(),
        );
  }

  /// Un videojuego puntual, también en tiempo real.
  /// Emite null si el documento no existe (por ejemplo, si se eliminó).
  Stream<Videojuego?> escucharUno(String id) {
    return _coleccion.doc(id).snapshots().map(
          (documento) =>
              documento.exists ? Videojuego.desdeFirestore(documento) : null,
        );
  }

  /// Alta: crea un documento nuevo. Firestore genera el ID automáticamente.
  Future<void> crear(Videojuego juego) async {
    await _coleccion.add(juego.aFirestore());
  }

  /// Modificación: actualiza el mismo documento (mismo ID).
  Future<void> actualizar(Videojuego juego) async {
    await _coleccion.doc(juego.id).update(juego.aFirestore());
  }

  /// Baja: elimina el documento de Firestore.
  Future<void> eliminar(String id) async {
    await _coleccion.doc(id).delete();
  }
}
