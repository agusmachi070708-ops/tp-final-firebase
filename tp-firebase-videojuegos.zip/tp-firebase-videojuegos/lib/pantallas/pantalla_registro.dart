import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../providers/auth_providers.dart';
import '../router/rutas.dart';
import '../utils/validadores.dart';
import '../widgets/boton_principal.dart';
import '../widgets/campo_texto.dart';
import '../widgets/mensaje_error.dart';

class PantallaRegistro extends ConsumerStatefulWidget {
  const PantallaRegistro({super.key});

  @override
  ConsumerState<PantallaRegistro> createState() => _PantallaRegistroState();
}

class _PantallaRegistroState extends ConsumerState<PantallaRegistro> {
  final _formulario = GlobalKey<FormState>();
  final _nombre = TextEditingController();
  final _email = TextEditingController();
  final _contrasena = TextEditingController();
  final _confirmacion = TextEditingController();
  bool _ocultarContrasenas = true;
  String? _error;

  @override
  void dispose() {
    _nombre.dispose();
    _email.dispose();
    _contrasena.dispose();
    _confirmacion.dispose();
    super.dispose();
  }

  Future<void> _crearCuenta() async {
    if (ref.read(sesionControllerProvider).isLoading) return;
    // Se valida todo el formulario antes de enviarle nada a Firebase.
    if (!_formulario.currentState!.validate()) return;
    setState(() => _error = null);

    final error = await ref
        .read(sesionControllerProvider.notifier)
        .registrar(_nombre.text, _email.text, _contrasena.text);

    // Si Firebase creó la cuenta, la sesión queda iniciada y el router lleva
    // solo al listado. Si la rechazó, mostramos el motivo.
    if (mounted && error != null) setState(() => _error = error);
  }

  void _irAlLogin() {
    if (context.canPop()) {
      context.pop();
    } else {
      context.go(Rutas.login);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cargando = ref.watch(sesionControllerProvider).isLoading;

    return Scaffold(
      appBar: AppBar(title: const Text('Registro')),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _formulario,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    CampoTexto(
                      controlador: _nombre,
                      etiqueta: 'Nombre',
                      icono: Icons.person_outline,
                      validador: (valor) =>
                          validarObligatorio(valor, 'tu nombre'),
                    ),
                    const SizedBox(height: 16),
                    CampoTexto(
                      controlador: _email,
                      etiqueta: 'Email',
                      icono: Icons.email_outlined,
                      teclado: TextInputType.emailAddress,
                      validador: validarEmail,
                    ),
                    const SizedBox(height: 16),
                    CampoTexto(
                      controlador: _contrasena,
                      etiqueta: 'Contraseña',
                      icono: Icons.lock_outline,
                      oculto: _ocultarContrasenas,
                      validador: validarContrasena,
                      sufijo: IconButton(
                        tooltip: _ocultarContrasenas ? 'Mostrar' : 'Ocultar',
                        icon: Icon(
                          _ocultarContrasenas
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                        ),
                        onPressed: () => setState(
                          () => _ocultarContrasenas = !_ocultarContrasenas,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    CampoTexto(
                      controlador: _confirmacion,
                      etiqueta: 'Repetir contraseña',
                      icono: Icons.lock_outline,
                      oculto: _ocultarContrasenas,
                      accionTeclado: TextInputAction.done,
                      alEnviar: (_) => _crearCuenta(),
                      validador: (valor) =>
                          validarConfirmacion(valor, _contrasena.text),
                    ),
                    if (_error != null) ...[
                      const SizedBox(height: 16),
                      MensajeError(_error!),
                    ],
                    const SizedBox(height: 24),
                    BotonPrincipal(
                      texto: 'Crear cuenta',
                      cargando: cargando,
                      alPresionar: _crearCuenta,
                    ),
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: cargando ? null : _irAlLogin,
                      child: const Text('¿Ya tenés cuenta? Iniciá sesión'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
