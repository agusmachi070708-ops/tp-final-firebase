import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../modelos/videojuego.dart';
import '../providers/videojuegos_providers.dart';
import '../router/rutas.dart';
import '../utils/errores.dart';
import '../widgets/imagen_juego.dart';
import '../widgets/pantalla_mensaje.dart';

class PantallaDetalle extends ConsumerWidget {
  const PantallaDetalle({super.key, required this.id});

  final String id;

  Future<void> _eliminar(
    BuildContext context,
    WidgetRef ref,
    Videojuego juego,
  ) async {
    final colores = Theme.of(context).colorScheme;
    final confirmado = await showDialog<bool>(
      context: context,
      builder: (contextoDialogo) => AlertDialog(
        title: const Text('Eliminar videojuego'),
        content: Text(
          '¿Seguro que querés eliminar "${juego.titulo}"? '
          'Esta acción no se puede deshacer.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(contextoDialogo, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: colores.error,
              foregroundColor: colores.onError,
            ),
            onPressed: () => Navigator.pop(contextoDialogo, true),
            child: const Text('Eliminar'),
          ),
        ],
      ),
    );
    if (confirmado != true || !context.mounted) return;

    // Guardamos lo que vamos a necesitar antes de salir de esta pantalla.
    final abm = ref.read(abmVideojuegosProvider.notifier);
    final mensajes = ScaffoldMessenger.of(context);

    // Volvemos al listado y borramos el documento. Cuando Firestore lo
    // confirma, el juego desaparece solo de la lista (es un stream).
    volverAtras(context);
    final error = await abm.eliminar(juego.id);
    mensajes.showSnackBar(
      SnackBar(content: Text(error ?? 'Se eliminó "${juego.titulo}".')),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Se escucha el documento en tiempo real: si se edita, esta pantalla se
    // actualiza sola al volver del formulario.
    final estado = ref.watch(videojuegoProvider(id));

    return estado.when(
      loading: () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      error: (error, _) => PantallaMensaje(describirError(error)),
      data: (juego) => juego == null
          ? const PantallaMensaje('Este videojuego ya no existe.')
          : _detalle(context, ref, juego),
    );
  }

  Widget _detalle(BuildContext context, WidgetRef ref, Videojuego juego) {
    final textos = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: Text(juego.titulo),
        actions: [
          IconButton(
            tooltip: 'Editar',
            icon: const Icon(Icons.edit_outlined),
            onPressed: () => context.push(Rutas.edicion(juego.id)),
          ),
          IconButton(
            tooltip: 'Eliminar',
            icon: const Icon(Icons.delete_outline),
            onPressed: () => _eliminar(context, ref, juego),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: ImagenJuego(url: juego.imagenUrl),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(juego.titulo, style: textos.headlineSmall),
                const SizedBox(height: 8),
                _Dato(
                  icono: Icons.devices_other,
                  etiqueta: 'Plataforma',
                  valor: juego.plataforma,
                ),
                _Dato(
                  icono: Icons.category_outlined,
                  etiqueta: 'Género',
                  valor: juego.genero,
                ),
                _Dato(
                  icono: Icons.business_outlined,
                  etiqueta: 'Desarrolladora',
                  valor: juego.desarrolladora,
                ),
                _Dato(
                  icono: Icons.event_outlined,
                  etiqueta: 'Año de lanzamiento',
                  valor: '${juego.anioLanzamiento}',
                ),
                const Divider(height: 32),
                Text('Descripción', style: textos.titleMedium),
                const SizedBox(height: 8),
                Text(juego.descripcion, style: textos.bodyLarge),
                const SizedBox(height: 24),
                Text('ID en Firestore: ${juego.id}', style: textos.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Dato extends StatelessWidget {
  const _Dato({
    required this.icono,
    required this.etiqueta,
    required this.valor,
  });

  final IconData icono;
  final String etiqueta;
  final String valor;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icono),
      title: Text(valor),
      subtitle: Text(etiqueta),
    );
  }
}
