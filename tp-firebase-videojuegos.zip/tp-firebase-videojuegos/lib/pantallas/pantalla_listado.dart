import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../modelos/videojuego.dart';
import '../providers/auth_providers.dart';
import '../providers/videojuegos_providers.dart';
import '../router/rutas.dart';
import '../utils/errores.dart';
import '../widgets/imagen_juego.dart';

class PantallaListado extends ConsumerWidget {
  const PantallaListado({super.key});

  Future<void> _cerrarSesion(BuildContext context, WidgetRef ref) async {
    final confirmado = await showDialog<bool>(
      context: context,
      builder: (contextoDialogo) => AlertDialog(
        title: const Text('Cerrar sesión'),
        content: const Text('¿Querés salir de tu cuenta?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(contextoDialogo, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(contextoDialogo, true),
            child: const Text('Salir'),
          ),
        ],
      ),
    );
    if (confirmado != true || !context.mounted) return;

    // No navegamos a mano: al cerrarse la sesión, el router vuelve al login.
    await ref.read(sesionControllerProvider.notifier).cerrarSesion();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final usuario = ref.watch(usuarioLogueadoProvider);
    final videojuegos = ref.watch(videojuegosProvider);

    final nombre = usuario?.displayName ?? '';
    final saludo = nombre.isNotEmpty ? nombre : (usuario?.email ?? '');

    return Scaffold(
      appBar: AppBar(
        title: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Videojuegos'),
            if (saludo.isNotEmpty)
              Text(
                'Hola, $saludo',
                style: Theme.of(context).textTheme.bodySmall,
              ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Cerrar sesión',
            icon: const Icon(Icons.logout),
            onPressed: () => _cerrarSesion(context, ref),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push(Rutas.nuevoJuego),
        icon: const Icon(Icons.add),
        label: const Text('Agregar'),
      ),
      // El provider es un stream de Firestore: cualquier cambio en la
      // colección vuelve a dibujar esta lista automáticamente.
      body: videojuegos.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => _ErrorAlCargar(
          mensaje: describirError(error),
          alReintentar: () => ref.invalidate(videojuegosProvider),
        ),
        data: (lista) {
          if (lista.isEmpty) return const _SinVideojuegos();
          return ListView.builder(
            // Espacio abajo para que el botón "Agregar" no tape el último.
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 96),
            itemCount: lista.length,
            itemBuilder: (context, i) => _TarjetaVideojuego(juego: lista[i]),
          );
        },
      ),
    );
  }
}

class _TarjetaVideojuego extends StatelessWidget {
  const _TarjetaVideojuego({required this.juego});

  final Videojuego juego;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: ImagenJuego(url: juego.imagenUrl, ancho: 56, alto: 56),
        ),
        title: Text(
          juego.titulo,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        // Dato representativo de la temática: plataforma y año.
        subtitle: Text('${juego.plataforma} · ${juego.anioLanzamiento}'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => context.push(Rutas.detalle(juego.id)),
      ),
    );
  }
}

class _SinVideojuegos extends StatelessWidget {
  const _SinVideojuegos();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.sports_esports_outlined, size: 72),
            const SizedBox(height: 16),
            Text(
              'Todavía no hay videojuegos',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 4),
            const Text(
              'Tocá "Agregar" para cargar el primero.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorAlCargar extends StatelessWidget {
  const _ErrorAlCargar({required this.mensaje, required this.alReintentar});

  final String mensaje;
  final VoidCallback alReintentar;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off, size: 56),
            const SizedBox(height: 12),
            Text(mensaje, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: alReintentar,
              icon: const Icon(Icons.refresh),
              label: const Text('Reintentar'),
            ),
          ],
        ),
      ),
    );
  }
}
