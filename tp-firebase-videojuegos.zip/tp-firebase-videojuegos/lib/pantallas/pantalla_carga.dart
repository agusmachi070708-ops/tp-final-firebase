import 'package:flutter/material.dart';

/// Se muestra al abrir la app mientras Firebase verifica si quedó una sesión
/// iniciada. Apenas responde, el router lleva al login o al listado.
class PantallaCarga extends StatelessWidget {
  const PantallaCarga({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.sports_esports, size: 72),
            SizedBox(height: 24),
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Verificando sesión...'),
          ],
        ),
      ),
    );
  }
}
