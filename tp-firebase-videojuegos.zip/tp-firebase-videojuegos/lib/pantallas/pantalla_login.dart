import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../providers/auth_providers.dart';
import '../router/rutas.dart';
import '../utils/validadores.dart';
import '../widgets/boton_principal.dart';
import '../widgets/campo_texto.dart';
import '../widgets/mensaje_error.dart';

class PantallaLogin extends ConsumerStatefulWidget {
  const PantallaLogin({super.key});

  @override
  ConsumerState<PantallaLogin> createState() => _PantallaLoginState();
}

class _PantallaLoginState extends ConsumerState<PantallaLogin> {
  final _formulario = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _contrasena = TextEditingController();
  bool _ocultarContrasena = true;
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    _contrasena.dispose();
    super.dispose();
  }

  Future<void> _ingresar() async {
    if (ref.read(sesionControllerProvider).isLoading) return;
    if (!_formulario.currentState!.validate()) return;
    setState(() => _error = null);

    final error = await ref
        .read(sesionControllerProvider.notifier)
        .iniciarSesion(_email.text, _contrasena.text);

    // Si salió bien no hace falta navegar: el router detecta la sesión nueva
    // y muestra el listado. Si falló, mostramos el motivo en esta pantalla.
    if (mounted && error != null) setState(() => _error = error);
  }

  @override
  Widget build(BuildContext context) {
    final cargando = ref.watch(sesionControllerProvider).isLoading;

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _formulario,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.sports_esports, size: 72),
                    const SizedBox(height: 12),
                    Text(
                      'Ludoteca',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Iniciá sesión para ver la colección de videojuegos',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 32),
                    CampoTexto(
                      controlador: _email,
                      etiqueta: 'Email',
                      icono: Icons.email_outlined,
                      teclado: TextInputType.emailAddress,
                      validador: validarEmail,
                    ),
                    const SizedBox(height: 16),
                    CampoTexto(
                      controlador: _contrasena,
                      etiqueta: 'Contraseña',
                      icono: Icons.lock_outline,
                      oculto: _ocultarContrasena,
                      accionTeclado: TextInputAction.done,
                      alEnviar: (_) => _ingresar(),
                      validador: (valor) =>
                          validarObligatorio(valor, 'la contraseña'),
                      sufijo: IconButton(
                        tooltip: _ocultarContrasena ? 'Mostrar' : 'Ocultar',
                        icon: Icon(
                          _ocultarContrasena
                              ? Icons.visibility_outlined
                              : Icons.visibility_off_outlined,
                        ),
                        onPressed: () => setState(
                          () => _ocultarContrasena = !_ocultarContrasena,
                        ),
                      ),
                    ),
                    if (_error != null) ...[
                      const SizedBox(height: 16),
                      MensajeError(_error!),
                    ],
                    const SizedBox(height: 24),
                    BotonPrincipal(
                      texto: 'Ingresar',
                      cargando: cargando,
                      alPresionar: _ingresar,
                    ),
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed:
                          cargando ? null : () => context.push(Rutas.registro),
                      child: const Text('¿No tenés cuenta? Registrate'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
