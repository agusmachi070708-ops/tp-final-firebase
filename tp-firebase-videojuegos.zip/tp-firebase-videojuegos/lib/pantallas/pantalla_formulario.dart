import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../modelos/videojuego.dart';
import '../providers/videojuegos_providers.dart';
import '../router/rutas.dart';
import '../utils/errores.dart';
import '../utils/validadores.dart';
import '../widgets/boton_principal.dart';
import '../widgets/campo_texto.dart';
import '../widgets/imagen_juego.dart';
import '../widgets/pantalla_mensaje.dart';

/// Formulario de alta y de modificación.
///
/// Sin [idEdicion] crea un videojuego nuevo. Con [idEdicion] primero trae de
/// Firestore los datos actuales y arranca el formulario con esos valores.
class PantallaFormulario extends ConsumerWidget {
  const PantallaFormulario({super.key, this.idEdicion});

  final String? idEdicion;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final id = idEdicion;
    if (id == null) return const _FormularioVideojuego();

    return ref.watch(videojuegoProvider(id)).when(
          loading: () => const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          ),
          error: (error, _) => PantallaMensaje(describirError(error)),
          data: (juego) => juego == null
              ? const PantallaMensaje('Este videojuego ya no existe.')
              : _FormularioVideojuego(inicial: juego),
        );
  }
}

const _espacio = SizedBox(height: 16);

class _FormularioVideojuego extends ConsumerStatefulWidget {
  const _FormularioVideojuego({this.inicial});

  /// Datos actuales del videojuego. Es null cuando se está dando de alta.
  final Videojuego? inicial;

  @override
  ConsumerState<_FormularioVideojuego> createState() =>
      _FormularioVideojuegoState();
}

class _FormularioVideojuegoState extends ConsumerState<_FormularioVideojuego> {
  final _formulario = GlobalKey<FormState>();
  late final TextEditingController _titulo;
  late final TextEditingController _plataforma;
  late final TextEditingController _genero;
  late final TextEditingController _desarrolladora;
  late final TextEditingController _anio;
  late final TextEditingController _imagenUrl;
  late final TextEditingController _descripcion;

  bool get _esEdicion => widget.inicial != null;

  @override
  void initState() {
    super.initState();
    // En la edición, cada campo arranca con el dato actual del videojuego.
    final juego = widget.inicial;
    _titulo = TextEditingController(text: juego?.titulo);
    _plataforma = TextEditingController(text: juego?.plataforma);
    _genero = TextEditingController(text: juego?.genero);
    _desarrolladora = TextEditingController(text: juego?.desarrolladora);
    _anio = TextEditingController(
      text: juego == null ? '' : '${juego.anioLanzamiento}',
    );
    _imagenUrl = TextEditingController(text: juego?.imagenUrl);
    _descripcion = TextEditingController(text: juego?.descripcion);
  }

  @override
  void dispose() {
    for (final controlador in [
      _titulo,
      _plataforma,
      _genero,
      _desarrolladora,
      _anio,
      _imagenUrl,
      _descripcion,
    ]) {
      controlador.dispose();
    }
    super.dispose();
  }

  Future<void> _guardar() async {
    if (ref.read(abmVideojuegosProvider).isLoading) return;
    // Si falta algún campo obligatorio, no se guarda nada.
    if (!_formulario.currentState!.validate()) return;

    final juego = Videojuego(
      // En la edición se conserva el ID: así se actualiza el mismo documento.
      id: widget.inicial?.id ?? '',
      titulo: _titulo.text.trim(),
      plataforma: _plataforma.text.trim(),
      genero: _genero.text.trim(),
      desarrolladora: _desarrolladora.text.trim(),
      anioLanzamiento: int.parse(_anio.text.trim()),
      imagenUrl: _imagenUrl.text.trim(),
      descripcion: _descripcion.text.trim(),
    );

    final abm = ref.read(abmVideojuegosProvider.notifier);
    final error =
        _esEdicion ? await abm.actualizar(juego) : await abm.crear(juego);
    if (!mounted) return;

    final exito = _esEdicion ? 'Cambios guardados.' : 'Videojuego agregado.';
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(error ?? exito)),
    );
    if (error == null) volverAtras(context);
  }

  @override
  Widget build(BuildContext context) {
    final guardando = ref.watch(abmVideojuegosProvider).isLoading;

    return Scaffold(
      appBar: AppBar(
        title: Text(_esEdicion ? 'Editar videojuego' : 'Nuevo videojuego'),
      ),
      // Se usa SingleChildScrollView + Column (y no ListView) para que todos
      // los campos existan siempre y validate() los revise a todos.
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formulario,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              CampoTexto(
                controlador: _titulo,
                etiqueta: 'Título',
                icono: Icons.sports_esports_outlined,
                validador: (valor) => validarObligatorio(valor, 'el título'),
              ),
              _espacio,
              CampoTexto(
                controlador: _plataforma,
                etiqueta: 'Plataforma',
                pista: 'PC, PlayStation 5, Nintendo Switch...',
                icono: Icons.devices_other,
                validador: (valor) =>
                    validarObligatorio(valor, 'la plataforma'),
              ),
              _espacio,
              CampoTexto(
                controlador: _genero,
                etiqueta: 'Género',
                pista: 'Aventura, RPG, Shooter...',
                icono: Icons.category_outlined,
                validador: (valor) => validarObligatorio(valor, 'el género'),
              ),
              _espacio,
              CampoTexto(
                controlador: _desarrolladora,
                etiqueta: 'Desarrolladora',
                icono: Icons.business_outlined,
                validador: (valor) =>
                    validarObligatorio(valor, 'la desarrolladora'),
              ),
              _espacio,
              CampoTexto(
                controlador: _anio,
                etiqueta: 'Año de lanzamiento',
                icono: Icons.event_outlined,
                teclado: TextInputType.number,
                validador: validarAnio,
              ),
              _espacio,
              CampoTexto(
                controlador: _imagenUrl,
                etiqueta: 'URL de la imagen',
                pista: 'https://...',
                icono: Icons.link,
                teclado: TextInputType.url,
                validador: validarUrlImagen,
              ),
              _VistaPrevia(controlador: _imagenUrl),
              _espacio,
              CampoTexto(
                controlador: _descripcion,
                etiqueta: 'Descripción',
                icono: Icons.notes,
                lineas: 4,
                validador: (valor) =>
                    validarObligatorio(valor, 'la descripción'),
              ),
              const SizedBox(height: 24),
              BotonPrincipal(
                texto: _esEdicion ? 'Guardar cambios' : 'Agregar videojuego',
                cargando: guardando,
                alPresionar: _guardar,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Muestra la imagen mientras se escribe la URL, para comprobar que carga.
class _VistaPrevia extends StatelessWidget {
  const _VistaPrevia({required this.controlador});

  final TextEditingController controlador;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<TextEditingValue>(
      valueListenable: controlador,
      builder: (context, valor, _) {
        final url = valor.text.trim();
        if (validarUrlImagen(url) != null) return const SizedBox.shrink();
        return Padding(
          padding: const EdgeInsets.only(top: 12),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: ImagenJuego(url: url),
            ),
          ),
        );
      },
    );
  }
}
