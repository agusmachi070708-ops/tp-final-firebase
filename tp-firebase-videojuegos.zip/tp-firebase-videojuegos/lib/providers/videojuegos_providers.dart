import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../modelos/videojuego.dart';
import '../repositorios/videojuegos_repositorio.dart';
import '../utils/errores.dart';

final videojuegosRepositorioProvider = Provider<VideojuegosRepositorio>(
  (ref) => VideojuegosRepositorio(FirebaseFirestore.instance),
);

/// Listado de videojuegos en tiempo real.
///
/// Es autoDispose: cuando ninguna pantalla lo está usando (por ejemplo,
/// después de cerrar sesión) se corta la conexión con Firestore.
final videojuegosProvider = StreamProvider.autoDispose<List<Videojuego>>(
  (ref) => ref.watch(videojuegosRepositorioProvider).escucharTodos(),
);

/// Un videojuego según su ID, en tiempo real. Lo usan el detalle y el
/// formulario de edición, así que los dos se actualizan solos.
final videojuegoProvider =
    StreamProvider.autoDispose.family<Videojuego?, String>(
  (ref, id) => ref.watch(videojuegosRepositorioProvider).escucharUno(id),
);

/// Controla las operaciones del ABM: alta, modificación y baja.
///
/// Igual que el SesionController, su estado indica si hay una operación en
/// curso, para mostrar el indicador de carga y evitar guardar dos veces.
class AbmVideojuegosController extends AsyncNotifier<void> {
  @override
  FutureOr<void> build() {
    // Al principio no hay ninguna operación en curso.
  }

  VideojuegosRepositorio get _repositorio =>
      ref.read(videojuegosRepositorioProvider);

  Future<String?> crear(Videojuego juego) =>
      _ejecutar(() => _repositorio.crear(juego));

  Future<String?> actualizar(Videojuego juego) =>
      _ejecutar(() => _repositorio.actualizar(juego));

  Future<String?> eliminar(String id) =>
      _ejecutar(() => _repositorio.eliminar(id));

  /// Corre la operación marcando el estado como "cargando" mientras dura.
  /// Devuelve null si salió bien, o el mensaje de error para mostrar.
  Future<String?> _ejecutar(Future<void> Function() operacion) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(operacion);
    return state.hasError ? describirError(state.error) : null;
  }
}

final abmVideojuegosProvider =
    AsyncNotifierProvider<AbmVideojuegosController, void>(
  AbmVideojuegosController.new,
);
