import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../repositorios/auth_repositorio.dart';
import '../utils/errores.dart';

final authRepositorioProvider = Provider<AuthRepositorio>(
  (ref) => AuthRepositorio(FirebaseAuth.instance),
);

/// Estado de la sesión: el usuario logueado, o null si no hay nadie.
///
/// Al abrir la app empieza "cargando" hasta que Firebase responde si quedó
/// una sesión guardada. El router lo escucha para decidir qué pantalla mostrar.
final usuarioActualProvider = StreamProvider<User?>(
  (ref) => ref.watch(authRepositorioProvider).cambiosDeUsuario(),
);

/// Atajo para las pantallas: el usuario logueado, o null mientras carga o si
/// no hay sesión.
final usuarioLogueadoProvider = Provider<User?>((ref) {
  return switch (ref.watch(usuarioActualProvider)) {
    AsyncData(:final value) => value,
    _ => null,
  };
});

/// Controla las acciones de sesión: iniciar sesión, registrarse y salir.
///
/// Su estado indica si hay una operación en curso (AsyncLoading), si la última
/// salió bien (AsyncData) o si falló (AsyncError). Las pantallas lo usan para
/// mostrar el indicador de carga en el botón.
class SesionController extends AsyncNotifier<void> {
  @override
  FutureOr<void> build() {
    // Al principio no hay ninguna operación en curso.
  }

  AuthRepositorio get _repositorio => ref.read(authRepositorioProvider);

  /// Devuelve null si salió bien, o el mensaje de error para mostrar.
  Future<String?> iniciarSesion(String email, String contrasena) {
    return _ejecutar(
      () => _repositorio.iniciarSesion(email: email, contrasena: contrasena),
    );
  }

  /// Devuelve null si salió bien, o el mensaje de error para mostrar.
  Future<String?> registrar(String nombre, String email, String contrasena) {
    return _ejecutar(
      () => _repositorio.registrar(
        nombre: nombre,
        email: email,
        contrasena: contrasena,
      ),
    );
  }

  Future<void> cerrarSesion() => _repositorio.cerrarSesion();

  Future<String?> _ejecutar(Future<void> Function() accion) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(accion);
    return state.hasError ? describirError(state.error) : null;
  }
}

final sesionControllerProvider =
    AsyncNotifierProvider<SesionController, void>(SesionController.new);
