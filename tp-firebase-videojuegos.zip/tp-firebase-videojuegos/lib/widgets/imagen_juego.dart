import 'package:flutter/material.dart';

/// Muestra la imagen de un videojuego a partir de su URL.
///
/// Si la URL está vacía o la imagen no se puede descargar, muestra un ícono
/// en su lugar para que la pantalla no se rompa.
class ImagenJuego extends StatelessWidget {
  const ImagenJuego({super.key, required this.url, this.ancho, this.alto});

  final String url;
  final double? ancho;
  final double? alto;

  @override
  Widget build(BuildContext context) {
    final reemplazo = Container(
      width: ancho,
      height: alto,
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      alignment: Alignment.center,
      child: const Icon(Icons.image_not_supported_outlined),
    );

    if (url.isEmpty) return reemplazo;

    return Image.network(
      url,
      width: ancho,
      height: alto,
      fit: BoxFit.cover,
      errorBuilder: (context, error, stackTrace) => reemplazo,
      loadingBuilder: (context, imagen, progreso) {
        if (progreso == null) return imagen;
        return SizedBox(
          width: ancho,
          height: alto,
          child: const Center(
            child: CircularProgressIndicator(strokeWidth: 2),
          ),
        );
      },
    );
  }
}
