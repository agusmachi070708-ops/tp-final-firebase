import 'package:flutter/material.dart';

/// Botón principal de los formularios.
///
/// Mientras [cargando] es true queda deshabilitado y muestra un indicador de
/// progreso, así el usuario no puede enviar el formulario dos veces.
class BotonPrincipal extends StatelessWidget {
  const BotonPrincipal({
    super.key,
    required this.texto,
    required this.alPresionar,
    this.cargando = false,
  });

  final String texto;
  final VoidCallback alPresionar;
  final bool cargando;

  @override
  Widget build(BuildContext context) {
    return FilledButton(
      onPressed: cargando ? null : alPresionar,
      style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
      child: cargando
          ? const SizedBox.square(
              dimension: 22,
              child: CircularProgressIndicator(strokeWidth: 2.5),
            )
          : Text(texto),
    );
  }
}
