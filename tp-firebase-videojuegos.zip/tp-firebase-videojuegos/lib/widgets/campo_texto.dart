import 'package:flutter/material.dart';

/// Campo de texto con el estilo común de todos los formularios de la app.
class CampoTexto extends StatelessWidget {
  const CampoTexto({
    super.key,
    required this.controlador,
    required this.etiqueta,
    required this.icono,
    this.validador,
    this.pista,
    this.teclado,
    this.oculto = false,
    this.lineas = 1,
    this.sufijo,
    this.accionTeclado = TextInputAction.next,
    this.alEnviar,
  });

  final TextEditingController controlador;
  final String etiqueta;
  final IconData icono;
  final FormFieldValidator<String>? validador;

  /// Texto de ejemplo que aparece dentro del campo vacío.
  final String? pista;
  final TextInputType? teclado;

  /// Oculta el texto (para contraseñas).
  final bool oculto;
  final int lineas;

  /// Widget al final del campo (por ejemplo, el botón para ver la contraseña).
  final Widget? sufijo;
  final TextInputAction accionTeclado;

  /// Se ejecuta cuando el usuario confirma desde el teclado.
  final ValueChanged<String>? alEnviar;

  @override
  Widget build(BuildContext context) {
    final esMultilinea = !oculto && lineas > 1;

    return TextFormField(
      controller: controlador,
      validator: validador,
      obscureText: oculto,
      maxLines: esMultilinea ? lineas : 1,
      keyboardType: esMultilinea ? TextInputType.multiline : teclado,
      textInputAction: esMultilinea ? TextInputAction.newline : accionTeclado,
      onFieldSubmitted: alEnviar,
      decoration: InputDecoration(
        labelText: etiqueta,
        hintText: pista,
        prefixIcon: Icon(icono),
        suffixIcon: sufijo,
        alignLabelWithHint: esMultilinea,
        border: const OutlineInputBorder(),
      ),
    );
  }
}
