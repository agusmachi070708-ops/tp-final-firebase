import 'package:flutter/material.dart';

/// Pantalla simple con un mensaje centrado. Se usa cuando un videojuego no se
/// pudo cargar o ya no existe.
class PantallaMensaje extends StatelessWidget {
  const PantallaMensaje(this.mensaje, {super.key});

  final String mensaje;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text(mensaje, textAlign: TextAlign.center),
        ),
      ),
    );
  }
}
