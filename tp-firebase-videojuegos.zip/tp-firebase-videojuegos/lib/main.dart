import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Firebase tiene que estar inicializado antes de usar Auth o Firestore.
  // firebase_options.dart lo genera el comando `flutterfire configure`.
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // ProviderScope es el contenedor donde viven todos los providers de Riverpod.
  runApp(const ProviderScope(child: LudotecaApp()));
}
