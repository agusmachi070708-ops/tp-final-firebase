import 'package:flutter/widgets.dart';
import 'package:go_router/go_router.dart';

/// Direcciones de todas las pantallas de la app.
abstract final class Rutas {
  static const carga = '/';
  static const login = '/login';
  static const registro = '/registro';
  static const juegos = '/juegos';
  static const nuevoJuego = '/juegos/nuevo';

  static String detalle(String id) => '/juegos/$id';
  static String edicion(String id) => '/juegos/$id/editar';
}

/// Vuelve a la pantalla anterior o, si no hay ninguna, al listado.
void volverAtras(BuildContext context) {
  if (context.canPop()) {
    context.pop();
  } else {
    context.go(Rutas.juegos);
  }
}
