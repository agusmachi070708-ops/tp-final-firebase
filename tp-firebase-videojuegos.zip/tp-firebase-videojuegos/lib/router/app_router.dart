import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../pantallas/pantalla_carga.dart';
import '../pantallas/pantalla_detalle.dart';
import '../pantallas/pantalla_formulario.dart';
import '../pantallas/pantalla_listado.dart';
import '../pantallas/pantalla_login.dart';
import '../pantallas/pantalla_registro.dart';
import '../providers/auth_providers.dart';
import 'rutas.dart';

final routerProvider = Provider<GoRouter>((ref) {
  // GoRouter no puede escuchar providers directamente, así que copiamos el
  // estado de la sesión en un ValueNotifier. Cada vez que cambia (se abre la
  // app, alguien inicia o cierra sesión), el router vuelve a ejecutar
  // `redirect` y decide qué pantalla corresponde.
  final sesion = ValueNotifier<AsyncValue<User?>>(const AsyncLoading());
  ref.listen<AsyncValue<User?>>(
    usuarioActualProvider,
    (anterior, actual) => sesion.value = actual,
    fireImmediately: true,
  );

  final router = GoRouter(
    initialLocation: Rutas.carga,
    refreshListenable: sesion,
    redirect: (context, state) {
      final estado = sesion.value;
      final ruta = state.matchedLocation;

      // 1. Firebase todavía no respondió si hay una sesión guardada.
      if (estado is AsyncLoading) {
        return ruta == Rutas.carga ? null : Rutas.carga;
      }

      final haySesion = estado is AsyncData<User?> && estado.value != null;
      final esRutaPublica = ruta == Rutas.login || ruta == Rutas.registro;

      // 2. Sin sesión: solo se puede estar en el login o en el registro.
      if (!haySesion) return esRutaPublica ? null : Rutas.login;

      // 3. Con sesión: la carga, el login y el registro llevan al listado.
      if (esRutaPublica || ruta == Rutas.carga) return Rutas.juegos;

      return null;
    },
    routes: [
      GoRoute(
        path: Rutas.carga,
        builder: (context, state) => const PantallaCarga(),
      ),
      GoRoute(
        path: Rutas.login,
        builder: (context, state) => const PantallaLogin(),
      ),
      GoRoute(
        path: Rutas.registro,
        builder: (context, state) => const PantallaRegistro(),
      ),
      GoRoute(
        path: Rutas.juegos,
        builder: (context, state) => const PantallaListado(),
        routes: [
          // "nuevo" va antes que ":id" para que no se confunda con un ID.
          GoRoute(
            path: 'nuevo',
            builder: (context, state) => const PantallaFormulario(),
          ),
          GoRoute(
            path: ':id',
            builder: (context, state) =>
                PantallaDetalle(id: state.pathParameters['id']!),
            routes: [
              GoRoute(
                path: 'editar',
                builder: (context, state) => PantallaFormulario(
                  idEdicion: state.pathParameters['id']!,
                ),
              ),
            ],
          ),
        ],
      ),
    ],
  );

  ref.onDispose(() {
    router.dispose();
    sesion.dispose();
  });

  return router;
});
